package com.pixogram.media.plumbing.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;


import com.pixogram.media.plumbing.feignproxy.MediaServiceProxy;
import com.pixogram.media.plumbing.model.Media;

public class MediaController {

	@Autowired
	private MediaServiceProxy mediaProxy;
	
	private final String Media_url= "http://localhost//media-service/medias";
	
	
	@GetMapping("/media/{mediaId}") // GET HTTP VERB
	public ResponseEntity<com.pixogram.media.plumbing.model.Media> getById(@PathVariable Integer mediaId) {
		
		Media action = this.mediaProxy.findMediaById(mediaId);
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(action, HttpStatus.OK);

		return response;
	}
	
}
