package com.cts.training.mediaservice.service;

import java.util.List;
import java.util.Optional;

import com.cts.training.mediaservice.entities.Media;
import com.cts.training.mediaservice.model.MediaDataModel;

public interface MediaService {
	

	
public List<Media> getall();
public void save(MediaDataModel action);
public Optional<Media> getWithId(Integer id);
public void updateuser(MediaDataModel action);

}
