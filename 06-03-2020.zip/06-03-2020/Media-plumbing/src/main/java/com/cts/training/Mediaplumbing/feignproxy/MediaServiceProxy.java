package com.cts.training.Mediaplumbing.feignproxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cts.training.Mediaplumbing.model.Media;


// registering interface as feign client proxy
// 1. url (name of the microservice)
// 2. connection details of microservice (IP/PORT)
// @FeignClient(name = "movie-service", path = "http://localhost:9090") // context-path
@FeignClient(name = "api-gateway") // path is managed by server
// configure the Ribbon to load balance
@RibbonClient(name = "media-service") // will activate load balancing on movie-service
public interface MediaServiceProxy {
	@GetMapping("media-service/movies/{mediaId}")
	public ResponseEntity<Media> mediaDetail(@PathVariable Integer mediaId);
}
