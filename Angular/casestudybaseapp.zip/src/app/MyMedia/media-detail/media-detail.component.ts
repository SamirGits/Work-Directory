import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-media-detail',
  templateUrl: './media-detail.component.html',
  //styleUrls: ['./media-detail.component.css']
})
export class MediaDetailComponent implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }

}
