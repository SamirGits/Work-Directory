package com.cts.training.Mediaplumbing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaPlumbingApplicationTests {

	@Test
	void contextLoads() {
	}

}
