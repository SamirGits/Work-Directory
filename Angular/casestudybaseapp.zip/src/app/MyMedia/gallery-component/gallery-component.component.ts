import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gallery-component',
  templateUrl: './gallery-component.component.html',
  //styleUrls: ['./gallery-component.component.css']
})
export class GalleryComponentComponent implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }

}
