import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';

@Component({
  selector: 'app-navbar2',
  templateUrl: './navbar2.component.html',
  styleUrls: ['./navbar2.component.css']
})
export class Navbar2Component implements OnInit {

  user : UserRegistrationDetails;

  constructor( public userService :UserRegistrationService, public auth:AuthenticationService) { }

  ngOnInit() {
 
  this.userService.getOneUser(parseInt(this.auth.getUserId())).subscribe((response:UserRegistrationDetails) => {
    this.user= response;
    this.user.profile = " http://localhost:8765/user-service/users" +this.user.profile;
  });

}
}