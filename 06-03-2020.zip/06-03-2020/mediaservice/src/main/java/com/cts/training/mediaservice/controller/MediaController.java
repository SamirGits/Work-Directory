package com.cts.training.mediaservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.exception.MediaErrorResponse;
import com.cts.training.mediaservice.exception.MediaNotFoundException;
import com.cts.training.mediaservice.model.MediaDataModel;
import com.cts.training.mediaservice.model.MediaModel;
import com.cts.training.mediaservice.repository.MediaRepository;
import com.cts.training.mediaservice.service.IMediaService;



@RestController
public class MediaController {
	
private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private IMediaService mediaservice;
	
	@GetMapping("/media")
	public ResponseEntity<MediaModel> getall(){
		MediaModel medialist = new MediaModel();
		
		medialist.setMedialist(this.mediaservice.findAllMedias());
		ResponseEntity<MediaModel> result = new ResponseEntity<MediaModel>(medialist, HttpStatus.OK);
		return result;
		
	}
	
	@PostMapping("/media")
	public boolean save(@RequestBody MediaDataModel media) {
		this.mediaService.save(media);
		return true;
	}
	@GetMapping("/media/{mediaId}")
	public ResponseEntity<MediaDataModel> getById(@PathVariable Integer mediaId){
		MediaDataModel data = new MediaDataModel();
		Media record = new Media();
		Optional<Media> media = this.mediaService.getWithId(mediaId);
		if(media.isPresent())
			record = media.get();
		else {
			throw new MediaNotFoundException("Media not found");
		}
		data.setId(record.getId());
		data.setUserId(record.getUserId());
		data.setTitle(record.getTitle());
		data.setTags(record.getTags());
		data.setDescription(record.getDescription());
		data.setMimetype(record.getMimeType());
		data.setFile(record.getFileUrl());
		ResponseEntity<MediaDataModel> result = new ResponseEntity<MediaDataModel>(data, HttpStatus.OK);
		return result;
	}
	
	
	//update user
	@PutMapping("/media")
	public boolean update(@RequestBody MediaDataModel user) {
		
		this.mediaService.updateuser(user);
		return true;
		
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<MediaErrorResponse> productOperationErrorHAndler(Exception ex) {
		// create error object
		MediaErrorResponse error = new MediaErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<MediaErrorResponse> response =
										new ResponseEntity<MediaErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}
}










