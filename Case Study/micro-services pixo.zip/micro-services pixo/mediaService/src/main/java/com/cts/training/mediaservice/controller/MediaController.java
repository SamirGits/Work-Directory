package com.cts.training.mediaservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.mediaservice.entity.Media;

import com.cts.training.mediaservice.repository.MediaRepository;

@RestController
public class MediaController {

	// dependency
	@Autowired
	private MediaRepository mediaRepository;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/medias/{mediaId}")
	public ResponseEntity<Media> mediaDetail(@PathVariable Integer mediaId){
		Optional<Media> record =  this.mediaRepository.findById(mediaId);
		Media media = new Media();
		if(record.isPresent())
			media = record.get();
		ResponseEntity<Media> response = new ResponseEntity<Media>(media, HttpStatus.OK);
		return response;
	}
}












