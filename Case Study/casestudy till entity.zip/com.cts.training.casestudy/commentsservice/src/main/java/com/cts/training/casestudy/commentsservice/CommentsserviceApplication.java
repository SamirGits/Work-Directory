package com.cts.training.casestudy.commentsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommentsserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommentsserviceApplication.class, args);
	}

}
