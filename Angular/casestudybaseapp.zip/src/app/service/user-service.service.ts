import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/users.model';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  APURL=" http://localhost:3000/users";
  constructor(public http:HttpClient) { }
   addUsers(user:User):Observable<User>
   {
     return this.http.post<User>(this.APURL,user);
   }
   getAllUsers():Observable<User>
   {
     return this.http.get<User>(this.APURL);
   }
}
