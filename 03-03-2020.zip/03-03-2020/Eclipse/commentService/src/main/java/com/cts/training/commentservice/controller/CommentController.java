package com.cts.training.commentservice.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.commentservice.entity.Comment;
import com.cts.training.commentservice.repository.CommentRepository;
import com.cts.training.commentservice.service.ICommentService;


@RestController
public class CommentController {

	// dependency
	@Autowired
	private ICommentService commentservice;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}

	@GetMapping("/comment") // GET HTTP VERB
	public ResponseEntity<List<Comment>> exposeAll() {
		
		List<Comment> comment = this.commentservice.findAllComments();
		ResponseEntity<List<Comment>> response = 
								new ResponseEntity<List<Comment>>(comment, HttpStatus.OK);
		
		
		return response;
	}	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/comment/{commentsId}") // GET HTTP VERB
	public ResponseEntity<Comment> getById(@PathVariable Integer commentId) {
		
		Comment comment = this.commentservice.findCommentById(commentId);
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/comment") // POST HTTP VERB
	public ResponseEntity<Comment> save(@RequestBody Comment comment) {
		this.commentservice.addComment(comment);
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	
	
	@PutMapping("/Comment/{commentsId}")
	
		public ResponseEntity<Comment> saveUpdate(@PathVariable Integer commentId,@RequestBody Comment comment) {
		
		Comment c = new Comment (commentId,comment.getMediaId(),comment.getUserId(),comment.getComments(),comment.getCreatedOn());

		if(!this.commentservice.updateComment(c))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(c, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	@DeleteMapping("/Comment/{CommentId}")
	public ResponseEntity<Comment> delete(@PathVariable Integer commentId) {
		
		Comment comment = this.commentservice.findCommentById(commentId);
		this.commentservice.deleteComment(commentId);
		
		ResponseEntity<Comment> response = 
				new ResponseEntity<Comment>(comment, HttpStatus.OK);

		return response;
	}
	
	
	
}














