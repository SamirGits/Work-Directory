package com.cts.training.Newsfeedservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsfeedserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsfeedserviceApplication.class, args);
	}

}
