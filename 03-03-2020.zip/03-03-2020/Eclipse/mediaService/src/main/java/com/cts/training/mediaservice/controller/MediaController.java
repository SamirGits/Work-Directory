package com.cts.training.mediaservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.mediaservice.entity.Media;

import com.cts.training.mediaservice.repository.MediaRepository;
import com.cts.training.mediaservice.service.IMediaService;

@RestController
public class MediaController {

	// dependency
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private IMediaService mediaService;

	
	
	
	
	@GetMapping("/media") // GET HTTP VERB
	public ResponseEntity<List<Media>> exposeAll() {
		
		List<Media> media = this.mediaService.findAllMedias();
		ResponseEntity<List<Media>> response = 
								new ResponseEntity<List<Media>>(media, HttpStatus.OK);
		
		
		return response;
	}	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/media/{mediaId}") // GET HTTP VERB
	public ResponseEntity<Media> getById(@PathVariable Integer mediaId) {
		
		Media action = this.mediaService.findMediaById(mediaId);
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(action, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/media") // POST HTTP VERB
	public ResponseEntity<Media> save(@RequestBody Media action) {
		this.mediaService.addMedia(action);
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(action, HttpStatus.OK);

		return response;
	}
	
	
	
	@PutMapping("/media/{mediaId}")
	
		public ResponseEntity<Media> saveUpdate(@PathVariable Integer mediaId,@RequestBody Media media) {
		
		Media m = new Media (media.getId(),media.getUserId(),media.getTitle(),media.getDescription(),media.getMimeType(),media.getSize(),media.getPosterFileUrl(),media.getFileUrl(),media.getHide(),media.getCreatedOn(),media.getUpdatedOn(),media.getTags());

		if(!this.mediaService.updateMedia(m))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(m, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	@DeleteMapping("/media/{mediaId}")
	public ResponseEntity<Media> delete(@PathVariable Integer mediaId) {
		
		Media media = this.mediaService.findMediaById(mediaId);
		this.mediaService.deleteMedia(mediaId);
		
		ResponseEntity<Media> response = 
				new ResponseEntity<Media>(media, HttpStatus.OK);

		return response;
	}
	
	
}











