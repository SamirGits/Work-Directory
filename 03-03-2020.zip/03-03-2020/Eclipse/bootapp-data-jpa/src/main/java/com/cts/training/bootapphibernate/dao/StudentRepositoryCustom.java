package com.cts.training.bootapphibernate.dao;

import java.util.List;

import com.cts.training.bootapphibernate.entity.Student;

public interface StudentRepositoryCustom {
	// declare custom methods
	List<Student> someVeryComplexRequirement();
}
