import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {
  
 
  constructor(public formBuilder:FormBuilder, public route : Router,public service:UserRegistrationService,public auth:AuthenticationService) {
   
   }
/*
   checkUserName(){
    this.regname = this.myFormGroup.controls['username'].value;
     for(let u of this.userlist){
       //console.log(u.username);
       //console.log(u.uemail);
       //console.log(u.password);
       //console.log(u.profile);
       if(u.id === this.id)
        sessionStorage.setItem("url",u.profile)
        
        if(this.regname == u.username){
          this.erruser = "Already exist!!" ;
          break;
        }else{
          this.erruser = "Success" ;
        }
     }
   }
*/


  ngOnInit() {
    
}
}
