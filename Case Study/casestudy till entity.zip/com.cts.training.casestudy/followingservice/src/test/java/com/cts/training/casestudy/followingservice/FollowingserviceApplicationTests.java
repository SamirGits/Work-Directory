package com.cts.training.casestudy.followingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FollowingserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
