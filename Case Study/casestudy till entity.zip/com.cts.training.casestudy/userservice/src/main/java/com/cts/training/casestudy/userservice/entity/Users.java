package com.cts.training.casestudy.userservice.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.util.MimeType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@ToString

// to convert into JPA entity
@Entity // Registers the class as entity
// Define the mappings
@Table(name = "user")
public class Users {

	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // unique key and Auti Increment
	private Integer id;
	
	@Column(name = "username")
	private String username;
	@Column
	private String password;
	@Column
	private String email;
	@Column
	private String firstname;
	@Column
	private String lastname;
	@Column
	private Date dob;
	
	@Column
	private MimeType profilepic;
	
	@CreationTimestamp
	@Column 
	private LocalDate createdon;
	@UpdateTimestamp
	@Column
	private LocalDate updatedon;
	@Column
	private boolean enabled;
	
	
}
