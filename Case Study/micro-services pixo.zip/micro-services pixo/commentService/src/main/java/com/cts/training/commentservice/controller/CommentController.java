package com.cts.training.commentservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.cts.training.commentservice.entity.Comment;
import com.cts.training.commentservice.repository.CommentRepository;


@RestController
public class CommentController {

	// dependency
	@Autowired
	private CommentRepository commentRepository;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/comments/{commentId}")
	public ResponseEntity<Comment> commentDetail(@PathVariable Integer commentId){
		Optional<Comment> record =  this.commentRepository.findById(commentId);
	Comment comment = new Comment();
		if(record.isPresent())
			comment = record.get();
		ResponseEntity<Comment> response = new ResponseEntity<Comment>(comment, HttpStatus.OK);
		return response;
	}
}












