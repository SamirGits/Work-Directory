import { TestBed } from '@angular/core/testing';

import { UserLoggedInGuardService } from './user-login-gaurd.service';

describe('UserLoginGaurdService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserLoggedInGuardService = TestBed.get(UserLoggedInGuardService);
    expect(service).toBeTruthy();
  });
});
