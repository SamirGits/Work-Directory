package com.cts.training.casestudy.blockeduserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockedUserserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
