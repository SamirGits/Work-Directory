package com.cts.training.casestudy.newsfeedservice.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.util.MimeType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@ToString
@Entity
@Table
public class Newsfeed {
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // primary key and Auti Increment
	private Integer id;
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key and Auti Increment
	private Integer userid;
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key and Auti Increment
	private Integer mediaid;
	@Column
	private  String feed;
	
	@CreationTimestamp
	@Column
	private LocalDate createdon;
	
}

