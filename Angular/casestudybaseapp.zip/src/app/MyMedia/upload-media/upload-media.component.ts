import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload-media',
  templateUrl: './upload-media.component.html',
  //styleUrls: ['./upload-media.component.css']
})
export class UploadMediaComponent implements OnInit {

  constructor(public router:Router) { }

  ngOnInit() {
  }

}
