export class User
{
    id:number;
    userName:string;
    password:string;
    repeatPassword:string;
    email:string;
}