import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-follow',
  templateUrl: './follow.component.html',
  //styleUrls: ['./follow.component.css']
})
export class FollowComponent implements OnInit {

  constructor(public router: Router) { }

  ngOnInit() {
  }

}
