import { Injectable } from '@angular/core';
import { UserRegistrationService } from './user registration/user-registration.service';
import { UserRegistrationDetails } from '../model/User-registration';
import {map} from 'rxjs/operators';
import { HttpHeaders, HttpClient } from '@angular/common/http';

const VALIDATION_URL = "http://localhost:8765/user-service/login";


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  getAuthenticationToken: any;
 
  
 
 
  constructor(public http : HttpClient) { }

   /* id:number;
    userlist: Array<UserRegistrationDetails>;
    constructor(public service:UserRegistrationService) {
    this.service.getAllUsers().subscribe((Response:any)=>{this.userlist=Response;console.log(Response)});
     }*/
  
   /* authenticate(userid : string, pass : string): boolean{
      console.log("service")
      console.log(userid)
      console.log(pass)
      console.log(this.userlist)
      for(let u of this.userlist){
        console.log(u)
      if(userid === u.username && pass === u.password){
        sessionStorage.setItem("user", u.username);
        sessionStorage.setItem("uid", String(u.id));
        console.log("authenticate="+this.id)
        console.log("Logged in")
        return true;
      }
      
    
        
      }
      return false;
    }*/


    authenticate(userid : string, password : string){
      // create a security token
      let authenticationToken = "Basic " + window.btoa(userid + ":" + password);
      console.log(authenticationToken);
  
      let headers = new HttpHeaders({
        Authorization : authenticationToken
      });
  
      // send the request
      return this.http.get(VALIDATION_URL, {headers}).pipe(
        // success function
        map(successData=>{
          sessionStorage.setItem("user", userid);
          // save the token
          sessionStorage.setItem("token", authenticationToken);
          return successData;
        }),
        // failure function
        map(failureData=>{
          // console message 
          return failureData;
        })
      );
    }

  
   
    isUserLoggedIn(): boolean{
    
      let user = sessionStorage.getItem('user');
      if(user == null)
        return false;
      return true;  
    }
  
  getId():number{
    let a= Number(sessionStorage.getItem('uid'));
    console.log("in getid"+this.getId)
    return a;
  }
  
   
    logout(){
     
      sessionStorage.removeItem('user');
      
    }
  
    
    getUserDetails():string{
      let user = sessionStorage.getItem('user');
      return user;
    }
  }