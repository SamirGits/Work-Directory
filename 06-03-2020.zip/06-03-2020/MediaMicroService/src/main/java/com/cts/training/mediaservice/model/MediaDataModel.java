package com.cts.training.mediaservice.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MediaDataModel {
	private Integer id;
	private Integer userId;
	private String title;
	private String description;
	private String tags;
	private String mimetype;
	private String file;
}


