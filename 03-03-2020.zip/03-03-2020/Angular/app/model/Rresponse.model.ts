export class Response{
    message : String;
    timestamp : number;
    userId : number;
    // additional info
}