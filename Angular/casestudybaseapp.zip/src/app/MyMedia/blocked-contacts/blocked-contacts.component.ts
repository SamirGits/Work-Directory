import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocked-contacts',
  templateUrl: './blocked-contacts.component.html',
  //styleUrls: ['./blocked-contacts.component.css']
})
export class BlockedContactsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
