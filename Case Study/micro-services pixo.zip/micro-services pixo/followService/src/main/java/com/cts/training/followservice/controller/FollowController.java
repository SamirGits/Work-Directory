package com.cts.training.followservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.repository.FollowRepository;


@RestController
public class FollowController {

	// dependency
	@Autowired
	private FollowRepository followRepository;
	
	// REST method that will recieve a movie Id and return details of that movie
	// ENDPOINT : /movies/{movieId}
	@GetMapping("/follows/{followerId}")
	public ResponseEntity<Follow> followDetail(@PathVariable Integer followerId){
		Optional<Follow> record =  this.followRepository.findById(followerId);
	Follow follow = new Follow();
		if(record.isPresent())
			follow = record.get();
		ResponseEntity<Follow> response = new ResponseEntity<Follow>(follow, HttpStatus.OK);
		return response;
	}
}












