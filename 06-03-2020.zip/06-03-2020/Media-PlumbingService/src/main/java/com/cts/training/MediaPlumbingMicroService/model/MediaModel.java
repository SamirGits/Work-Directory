package com.cts.training.MediaPlumbingMicroService.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MediaModel implements Serializable {
	
	private Integer userId;
	private String title;
	private String description;
	private String mimeType;
	private Integer size;
	private String posterFileurl;
	private String url;
	private Boolean hide;
	private String tags;
	

}
