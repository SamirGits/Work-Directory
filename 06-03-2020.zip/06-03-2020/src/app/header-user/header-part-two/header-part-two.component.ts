import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserAuthService } from 'src/app/services/user-auth.service';

@Component({
  selector: 'app-header-part-two',
  templateUrl: './header-part-two.component.html',
  styleUrls: ['./header-part-two.component.css']
})
export class HeaderPartTwoComponent implements OnInit {
  username : string;
  profile_pic : string;


  constructor(public auth : AuthenticationService , public userName : UserAuthService) {
    this.username=this.auth.getUserDetails();
    //sessionStorage.setItem("sample",this.auth.getPic());
    this.profile_pic="http://localhost:8765/user-service/"+this.userName.getPic();
    console.log("constructor :"+this.profile_pic);
   }

  ngOnInit() {
   
    //this.profile_pic= "http://localhost:8765/user-service/"+this.auth.getPic();
  }

}
