import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';

@Component({
  selector: 'app-account-update',
  templateUrl: './account-update.component.html',
  styleUrls: ['./account-update.component.css']
})
export class AccountUpdateComponent implements OnInit {
  user : string;
  pass: string;
  repass : string;
  email : string;
  errtext : string='';
  sucesstxt:string;
  myFormGroup : FormGroup;
 
  constructor(formBuilder: FormBuilder, public route : Router, public details:UserRegistrationService) {
    console.log("in form  builder of reg") ;
    this.myFormGroup=formBuilder.group({
    "username" : new FormControl(""),
    "email" : new FormControl(""),
    "password" : new FormControl(""),
    "repassword" : new FormControl(""),
   
  });
   }
   update(){
      
  
    this.user = this.myFormGroup.controls['username'].value;
    this.email = this.myFormGroup.controls['email'].value;
    this.pass = this.myFormGroup.controls['password'].value;
    this.repass = this.myFormGroup.controls['repassword'].value;

   
     

  if (this.pass === this.repass){
  console.log("username :" +this.user+"\n" + "email :" +this.email+"\n"+ "password :"+this.pass+"\n"+ "repassword :"+this.repass+"\n");
        this.sucesstxt = "registerd successfully";
       this.errtext="";
       
  
     }
     else{
      this.errtext = "Password not matched";
     this.sucesstxt="";
     }

      
  }
 
   

  ngOnInit() {
  }

}
