package com.cts.training.casestudy.actionservice.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.util.MimeType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;



@Getter
@Setter
@AllArgsConstructor
@ToString
@Entity
@Table
public class Actions {
	
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // primary key and Auto Increment
	private Integer id;
	
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key from media and Auti Increment
	private Integer mediaid;
	
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key from users and Auti Increment
	private Integer userid;
	
	@Column
	private boolean status;
	
	@CreationTimestamp
	@Column
	private LocalDate createdon;
	
	
	 
}
