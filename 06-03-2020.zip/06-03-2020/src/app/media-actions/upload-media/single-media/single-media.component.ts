import { Component, OnInit } from '@angular/core';
import{FormGroup, FormControl, FormBuilder, Validators} from'@angular/forms';
import { HttpEvent } from '@angular/common/http';
@Component({
  selector: 'app-single-media',
  templateUrl: './single-media.component.html',
  styleUrls: ['./single-media.component.css']
})
export class SingleMediaComponent implements OnInit {
  title:string;
  description : string;
  tags: string;
  date: Date;
  currentFileUpload: any;
  fileUrl: string;
  mediaservice: any;
  router: any;
  selectedFiles: any;
  myFormGroup:FormGroup;
  submit: boolean=false;
  constructor(formBuilder: FormBuilder) {
    console.log("in form bilder of single media");
    this.myFormGroup=formBuilder.group({
      "title":new FormControl(""),
      "description":new FormControl(""),
      "tags":new FormControl("")
    });

  }
selectFile(event){
  this.selectedFiles = event.target.files;
}
upload():void{
  this.title= this.myFormGroup.controls['title'].value;
  this.description= this.myFormGroup.controls['description'].value;
  this.tags= this.myFormGroup.controls['tags'].value;
  this.date= new Date();
  this.currentFileUpload=this.selectedFiles.item(0);
  let dateString = `_${this.date.getTime()}_${this.date.getFullYear()}`
  if(this.currentFileUpload.type == 'image/png'){
    this.fileUrl =`${this.title}${dateString}.png`;
  }
  if(this.currentFileUpload.type == 'image/jpeg' || this.currentFileUpload.type == 'image/jpg'){
    this.fileUrl =`${this.title}${dateString}.jpeg`;
  }


  this.mediaservice.pushFileToStorage(this.currentFileUpload,this.title,this.description,this.tags,this.fileUrl,this.currentFileUpload.type).subscribe((event:HttpEvent<{}>) => {
    alert("media Uploaded Successfully");

    this.router.navigate(['/media/'])
  })
}

  
message(){
  console.log("Submitted Succesfully...!!!")
}
  ngOnInit() {
  }

}
