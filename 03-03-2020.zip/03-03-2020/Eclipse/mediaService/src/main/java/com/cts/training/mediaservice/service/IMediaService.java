package com.cts.training.mediaservice.service;

import java.util.List;

import com.cts.training.mediaservice.entity.Media;







public interface IMediaService {

	List<Media> findAllMedias();
	Media findMediaById(Integer id);
	boolean addMedia(Media Media);
	boolean updateMedia(Media Media);
	boolean deleteMedia(Integer id);
}
