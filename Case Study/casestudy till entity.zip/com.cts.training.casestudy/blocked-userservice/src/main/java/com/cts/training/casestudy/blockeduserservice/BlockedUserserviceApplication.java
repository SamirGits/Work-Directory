package com.cts.training.casestudy.blockeduserservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockedUserserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockedUserserviceApplication.class, args);
	}

}
