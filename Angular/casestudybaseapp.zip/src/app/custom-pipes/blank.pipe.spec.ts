import { BlankPipe } from './blank.pipe';

describe('BlankPipe', () => {
  it('create an instance', () => {
    const pipe = new BlankPipe();
    expect(pipe).toBeTruthy();
  });
});
