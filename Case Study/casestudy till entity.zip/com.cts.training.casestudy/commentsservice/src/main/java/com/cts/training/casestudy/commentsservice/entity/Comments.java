package com.cts.training.casestudy.commentsservice.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.util.MimeType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@ToString
@Entity
@Table
public class Comments {
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // primary key and Auto Increment
	private Integer id;
	
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key from media key and Auti Increment
	private Integer mediaid;
	
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key from users and Auti Increment
	private Integer userid;
	@Column
	private String comments;
	
	@CreationTimestamp
	@Column
	private LocalDate createdon;
	

}
