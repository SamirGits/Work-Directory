import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserRegistrationDetails } from 'src/app/model/User-registration';
import { Router } from '@angular/router';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';

@Component({
  selector: 'app-followers-following',
  templateUrl: './followers-following.component.html',
  styleUrls: ['./followers-following.component.css']
})
export class FollowersFollowingComponent implements OnInit {
  
  constructor(public auth :AuthenticationService,private router:Router,private userservice:UserRegistrationService) { }

  ngOnInit() {
    
    }
  
}
