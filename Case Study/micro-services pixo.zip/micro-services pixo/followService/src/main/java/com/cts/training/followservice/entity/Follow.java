package com.cts.training.followservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table
public class Follow {
	
	@Id
	private Integer userId;
	@Column
	private Integer followerId;
	
	
	public Follow() {
		// TODO Auto-generated constructor stub
	}
	
	public Follow(Integer userId, Integer followerId) {
		
		this.userId = userId;
		this.followerId = followerId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getFollowerId() {
		return followerId;
	}
	public void setFollowerId(Integer followerId) {
		this.followerId = followerId;
	}

	@Override
	public String toString() {
		return "Following [userId=" + userId + ", followerId=" + followerId + "]";
	}
	
	
}
