package com.cts.training.pixogram.MediaMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
