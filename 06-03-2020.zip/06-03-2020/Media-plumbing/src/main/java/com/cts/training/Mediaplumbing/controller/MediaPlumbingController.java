package com.cts.training.Mediaplumbing.controller;

import java.security.Provider.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.cts.training.Mediaplumbing.feignproxy.MediaServiceProxy;
import com.cts.training.Mediaplumbing.model.Media;

@RestController
public class MediaPlumbingController {
	
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private Service storageService;
	
	@Autowired
	private MediaServiceProxy mediaProxy;

	
	
	private final String MEDIA_URL = "http://localhost:9100/media-service/medias"; 
	
	@PostMapping("/medias")
	 public ResponseEntity<Media> save(@RequestParam("file") MultipartFile file,
			 							@Requestparam("mediaId") Integer userId;
			 );



}
