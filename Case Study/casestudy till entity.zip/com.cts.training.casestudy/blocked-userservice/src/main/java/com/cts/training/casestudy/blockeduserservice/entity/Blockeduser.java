package com.cts.training.casestudy.blockeduserservice.entity;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.util.MimeType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@ToString
@Entity
@Table
public class Blockeduser {
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key and Auti Increment
	private Integer userid;
	@Id // primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // foreign key,unique key and Auti Increment
	private Integer blockeduserid;
	
	
}
