package com.cts.training.pixogram.MediaPlumbingMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaPlumbingMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
